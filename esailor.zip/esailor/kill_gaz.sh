#!/bin/bash

pkill -f gzserver
pkill -f gzclient
pkill -f rosmaster
pkill -f rosout
pkill -f python
pkill -f eboat_ocean_qle
pkill -f eboat_ocean_CC
